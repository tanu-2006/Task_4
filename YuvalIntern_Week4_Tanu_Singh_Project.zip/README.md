# YuvalIntern Week 4 — Supervised Learning Model Implementation

**Trainee:** Tanu Singh  
**Role:** Virtual Data Science with Python Trainee

## Objective
Build and evaluate a supervised machine-learning model using a public dataset.

## Dataset
The public Breast Cancer Wisconsin (Diagnostic) dataset distributed through scikit-learn. The task is binary classification: malignant vs benign.

## Model
- Train/test split: 80/20, stratified
- Feature scaling: StandardScaler
- Classifier: Logistic Regression
- Validation: 5-fold Stratified Cross-Validation
- Metrics: Accuracy, Precision, Recall, F1, ROC-AUC
- Random state: 42

## Test Results
- Accuracy: 0.982
- Precision: 0.986
- Recall: 0.986
- F1 Score: 0.986
- ROC-AUC: 0.995
- Mean 5-fold CV Accuracy: 0.974

## Structure
- `data/` — dataset and evaluation outputs
- `figures/` — model visualizations
- `src/` — reproducible Python script
- `reports/` — final Word report
